﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventario
{
	class OrderApi : AbstractApi
	{
		protected override string GetPath => "orders";

		protected override string PostPath => "orders";

		protected override string PutPath => "orders/{orderId}";

		protected override string DeletePath => "orders/{orderId}";

		public async Task<Order> Create( Order data)
		{
			var response = await _Create(data);
			return JsonConvert.DeserializeObject<Order>(await response.Content.ReadAsStringAsync());
		}

		public async Task<Order> Delete(string id)
		{
			var response = await _Delete(id);
			return JsonConvert.DeserializeObject<Order>(await response.Content.ReadAsStringAsync());
		}

		public async Task<List<Order>> GetAll()
		{
			var response = await _GetAll();
			return JsonConvert.DeserializeObject<List<Order>>(await response.Content.ReadAsStringAsync());
		}

		public async Task<Order> Update(string id, Order data)
		{
			var response = await _Update(id,data);
			return JsonConvert.DeserializeObject<Order>(await response.Content.ReadAsStringAsync());
		}
	}
}
