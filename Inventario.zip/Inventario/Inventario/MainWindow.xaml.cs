﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Inventario
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void clientButton_Click(object sender, RoutedEventArgs e)
		{
			new FormularioClients().ShowDialog();
		}

		private void productButton_Click(object sender, RoutedEventArgs e)
		{
			new Formulario().ShowDialog();
		}

		private void ordersButton_Click(object sender, RoutedEventArgs e)
		{
			new FormularioOrders().ShowDialog();
		}

		private async void Grid_Loaded(object sender, RoutedEventArgs e)
		{
			ClientApi clientApi = new ClientApi();
			var clients = await clientApi.GetAll();
			dataGrid.ItemsSource = clients;
		}
	}
}
