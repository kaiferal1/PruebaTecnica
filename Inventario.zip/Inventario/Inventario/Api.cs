﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventario
{
	public static class Api
	{

		public enum Apis
		{
			client,product,order
		}
		public static AbstractApi GetApi(Apis apis)
		{
			switch (apis)
			{
				case Apis.client:
					return new ClientApi();
				case Apis.order:
					return new OrderApi();
				case Apis.product:
					return new ProductApi();
				default:
					return new ClientApi();
			}
		}
	}
}
