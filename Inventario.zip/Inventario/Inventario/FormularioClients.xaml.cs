﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Inventario
{
	/// <summary>
	/// Interaction logic for FormularioClients.xaml
	/// </summary>
	public partial class FormularioClients : Window
	{
		ClientApi clientApi = new ClientApi();
		List<Client> clients;

		public FormularioClients()
		{
			InitializeComponent();
		}

		private async void AddButton_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				await clientApi.Create(new Client
				{
					name = NameTextBox.Text,
					description = DescriptionTextbox.Text,
					address = AddresTextBox.Text,
					email = EmailTextBox.Text,
					RFC = RFCTextBox.Text,
					telephone = PhoneTextBox.Text,
					
				});
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Error");
			}
		}

		private async Task Sync()
		{
			clients = await clientApi.GetAll();
			dataGrid.ItemsSource = clients;
		}

		private  async void DeleteButton_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				await clientApi.Delete(clients[dataGrid.SelectedIndex].id);
				await Sync();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Error");
			}
		}

		private async void ModifyButton_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				await clientApi.Update(clients[dataGrid.SelectedIndex].id, new Client
				{
					name = NameTextBox.Text,
					description = DescriptionTextbox.Text,
					address = AddresTextBox.Text,
					email = EmailTextBox.Text,
					RFC = RFCTextBox.Text,
					telephone = PhoneTextBox.Text,
				});
				await Sync();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Error");
			}
		}

		private async void Grid_Loaded(object sender, RoutedEventArgs e)
		{
			await Sync();
		}
	}
}
