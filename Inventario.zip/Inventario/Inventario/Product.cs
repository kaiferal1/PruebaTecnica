﻿using System;

namespace Inventario
{
	public class Product : Modelo
	{
		public string id { get; set; }
		public string name { get; set; }
		public string description { get; set; }
		public double unitPrice { get; set; }
		public double cost { get; set; }
		public DateTime? expiryDate { get; set; }
		public int stock { get; set; }
	}
}