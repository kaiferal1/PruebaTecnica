﻿using Microsoft.OpenApi.Models;
using Microsoft.OpenApi.Readers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Inventario
{
	public abstract class AbstractApi
	{
		protected const string BASEURL = "http://localhost:8080/api/";
		protected abstract string GetPath { get; }
		protected abstract string PostPath { get; }
		protected abstract string PutPath { get; }
		protected abstract string DeletePath { get; }

		protected OpenApiDocument openApiDocument;

		protected AbstractApi()
		{

		}
		protected async Task<HttpResponseMessage> _GetAll()
		{
			var httpClient = new HttpClient();
			var request = new HttpRequestMessage(HttpMethod.Get, BASEURL + GetPath);
			var response = await httpClient.SendAsync(request);
			if (!response.IsSuccessStatusCode)
			{
				throw new Exception(await response.Content.ReadAsStringAsync());
			}
			return response;
		}
		protected async Task<HttpResponseMessage> _Create(object data)
		{
			using (var client = new HttpClient())
			{
				string json = JsonConvert.SerializeObject(data);
				var dataRequest = new StringContent(json, Encoding.UTF8, "application/json");
				var response = await client.PostAsync(BASEURL + PostPath, dataRequest);
				if (!response.IsSuccessStatusCode)
				{
					throw new Exception(await response.Content.ReadAsStringAsync());
				}
				return response;
			};
		}
		protected async Task<HttpResponseMessage> _Update(string id, object data)
		{
			var client = new HttpClient();
			var dataJson = JsonConvert.SerializeObject(data);
			var dataString = new StringContent(dataJson, Encoding.UTF8, "application/json");
			var response = await client.PutAsync(BASEURL + Regex.Replace(PutPath,@"{\w+}" ,id), dataString);
			if (!response.IsSuccessStatusCode)
			{
				throw new Exception(await response.Content.ReadAsStringAsync());
			}
			return response;
		}
		protected async Task<HttpResponseMessage> _Delete(string id)
		{
			var client = new HttpClient();
			var response = await client.DeleteAsync(BASEURL + Regex.Replace(PutPath, @"{\w+}", id));
			if (!response.IsSuccessStatusCode)
			{
				throw new Exception(await response.Content.ReadAsStringAsync());
			}
			return response;
		}
	}
}
