﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.OpenApi;
using Microsoft.OpenApi.Readers;
using Newtonsoft.Json;

namespace Inventario
{
	class ClientApi : AbstractApi
	{
		protected override string GetPath { get => "clients"; }
		protected override string PostPath { get => "clients"; }
		protected override string PutPath { get => "clients/{clientId}"; }
		protected override string DeletePath { get => "clients/{clientId}"; }

		public async Task<Client> Create(Client data)
		{
			var response = await _Create(data);
			return JsonConvert.DeserializeObject<Client>(await response.Content.ReadAsStringAsync());
		}

		public async Task<Client> Delete(string id)
		{
			var response = await _Delete(id);
			return JsonConvert.DeserializeObject<Client>(await response.Content.ReadAsStringAsync());
		}

		public async Task<List<Client>> GetAll()
		{
			var response = await _GetAll();
			return JsonConvert.DeserializeObject<List<Client>>(await response.Content.ReadAsStringAsync());
		}

		public async Task<Client> Update(string id, Client data)
		{
			var response = await _Update(id, data);
			return JsonConvert.DeserializeObject<Client>(await response.Content.ReadAsStringAsync());
		}
	}
}
