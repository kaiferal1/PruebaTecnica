﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventario
{
	public class Client : Modelo
	{

		public string id { get; set; }
		public string name { get; set; }
		public string description { get; set; }
		public DateTime createdAt { get; set; }
		public string RFC { get; set; }
		public string address { get; set; }
		public string telephone { get; set; }
		public string email { get; set; }
		public List<Order> orders { get; set; }
	}
}
