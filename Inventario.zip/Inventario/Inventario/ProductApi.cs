﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventario
{
	class ProductApi : AbstractApi
	{
		protected override string GetPath =>"products";

		protected override string PostPath => "products";

		protected override string PutPath => "products/{idProduct}";

		protected override string DeletePath => "products/{idProduct}";

		public async Task<Product> Create(Product data)
		{
			var response = await _Create(data);
			return JsonConvert.DeserializeObject<Product>(await response.Content.ReadAsStringAsync());
		}

		public async Task<Product> Delete(string id)
		{
			var response = await _Delete(id);
			return JsonConvert.DeserializeObject<Product>(await response.Content.ReadAsStringAsync());
		}

		public async Task<List<Product>> GetAll()
		{
			var response = await _GetAll();
			return JsonConvert.DeserializeObject<List<Product>>(await response.Content.ReadAsStringAsync()); 
		}

		public async Task<Product> Update(string id, Product data)
		{
			var response = await _Update(id,data);
			return JsonConvert.DeserializeObject<Product>(await response.Content.ReadAsStringAsync());
		}
	}
}
