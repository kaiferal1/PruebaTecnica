﻿using System;

namespace Inventario
{
	public class Order : Modelo
	{
		public string id { get; set; }
		public Client client { get; set; }
		public Product product { get; set; }
		public DateTime date { get; set; }
		public int quantity { get; set; }
	}

}