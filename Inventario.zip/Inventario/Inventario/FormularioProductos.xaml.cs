﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static Inventario.Api;

namespace Inventario
{

	public partial class Formulario : Window
	{
		ProductApi ProductApi = new ProductApi();
		List<Product> products;
		public Formulario()
		{
			InitializeComponent();
		}

		private void dataGrid_Copy_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{

		}

		private async void Grid_Loaded(object sender, RoutedEventArgs e)
		{
			await Sync();
		}

		private async Task Sync()
		{
			products = await ProductApi.GetAll();
			dataGrid.ItemsSource = products;
		}

		private async void addButton_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				await ProductApi.Create(new Product
				{
					name = nombre.Text,
					cost = double.Parse(costo.Text),
					description = descripcion.Text,
					stock = int.Parse(stock.Text),
					unitPrice = double.Parse(precio.Text)
				});
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Error");
			}
		}

		private void dataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			
		}

		private async void modifyButton_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				await ProductApi.Update(products[dataGrid.SelectedIndex].id, new Product
				{
					name = nombre.Text,
					cost = double.Parse(costo.Text),
					description = descripcion.Text,
					stock = int.Parse(stock.Text),
					unitPrice = double.Parse(precio.Text)
				});
				await Sync();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Error");
			}
		}

		private async void deleteButton_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				await ProductApi.Delete(products[dataGrid.SelectedIndex].id);
				await Sync();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Error");
			}
		}
	}
}
