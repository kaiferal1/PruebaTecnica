﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Inventario
{
	/// <summary>
	/// Interaction logic for FormularioOrders.xaml
	/// </summary>
	public partial class FormularioOrders : Window
	{
		OrderApi orderApi = new OrderApi();
		List<Order> orders;

		public FormularioOrders()
		{
			InitializeComponent();
		}

		private async void AddButton_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				await orderApi.Create(new Order
				{
					client = new Client() { id = ClienteTextBox.Text },
					product = new Product() { id = ProductoTextBox.Text },
					quantity = int.Parse(CantidadTextBox.Text)
				});
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Error");
			}
		}

		private async Task Sync()
		{
			try
			{

				orders = await orderApi.GetAll();
				dataGrid.ItemsSource = orders;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Error");
			}
		}

		private async void DeleteButton_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				await orderApi.Delete(orders[dataGrid.SelectedIndex].id);
				await Sync();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Error");
			}
		}

		private async void ModifyButton_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				await orderApi.Update(orders[dataGrid.SelectedIndex].id, new Order
				{
					client = new Client() { id = ClienteTextBox.Text },
					product = new Product() { id = ProductoTextBox.Text },
					quantity = int.Parse(CantidadTextBox.Text)
				});
				await Sync();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Error");
			}
		}

		private async void Grid_Loaded(object sender, RoutedEventArgs e)
		{
			await Sync();
		}

	}
}
